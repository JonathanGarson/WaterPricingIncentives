# Replication Package

We provide a critical replication of the package of [Chakravorty, Ujjayant, Manzoor H. Dar, and Kyle Emerick. 2023. "Inefficient Water Pricing and Incentives for Conservation."](https://www.aeaweb.org/articles?id=10.1257/app.20210011)  published in the American Economic Review. 
This replication package is part of the work for final year graduate program at SciencesPo Paris in Development Economics. 

Authors: Mathilde Blanchon and Jonathan Garson.
